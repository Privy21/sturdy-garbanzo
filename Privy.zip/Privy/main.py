from flask import Flask, render_template


app = Flask('app')

@app.route('/')
def hello_world():
  return render_template('index.html')

@app.route('/exp')
def experience():
  return render_template('exp.html')

@app.route('/cert')
def certificate():
  return render_template('cert.html')

@app.route('/edu')
def education():
  return render_template('edu.html')

@app.route('/skills')
def skills():
  return render_template('skills.html')
  
app.run(host='0.0.0.0', port=8080)
