import openpyxl
import requests
from datetime import datetime, timedelta
from openpyxl.chart import Reference, Series, PieChart, BarChart, LineChart, ScatterChart

wb = openpyxl.Workbook()
sheet = wb.active
sheet.title = "Gold Prices"

# Fetching data from the National Bank of Poland API

# Dates 10 days ago and today
end_date = datetime.now().strftime('%Y-%m-%d')
start_date = (datetime.now() - timedelta(days=12 )).strftime('%Y-%m-%d')

url = f'https://api.nbp.pl/api/cenyzlota/{start_date}/{end_date}'

response = requests.get(url, headers={'Accept': 'application/json'})
data = response.json()  # This handles JSON decoding automatically
#print(data)

# Adding headers to the sheet
sheet.append(['Date', 'Price'])

# Adding data to the sheet
for item in data:
    date = item['data']
    price = item['cena']
    sheet.append([date, price])

# Referencing the dates and values variables with columns in the sheet 
dates = Reference(sheet, min_col=1, min_row=2, max_row=len(data)+1)
values = Reference(sheet, min_col=2, min_row=2, max_row=len(data)+1)

# Creating a bar chart
bar_chart = BarChart()
bar_chart.add_data(values, titles_from_data=True)
bar_chart.title = 'Gold Prices Over The Last 10 Days - Bar Chart'
bar_chart.x_axis.title = 'Date'
bar_chart.y_axis.title = 'Price'
bar_chart.set_categories(dates)
sheet.add_chart(bar_chart, 'F1')

# Creating a line chart
line_chart = LineChart()
line_chart.add_data(values, titles_from_data=True)
line_chart.title = 'Gold Prices Over The Last 10 Days - Line Chart'
line_chart.x_axis.title = 'Date'
line_chart.y_axis.title = 'Price'
line_chart.set_categories(dates)
sheet.add_chart(line_chart, 'F20')

# Creating a pie chart
pie_chart = PieChart()
pie_chart.title = 'Gold Prices Over The Last 10 Days - Pie Chart'
pie_chart.add_data(values, titles_from_data=True)
pie_chart.set_categories(dates)
sheet.add_chart(pie_chart, 'F40')

# Creating a scatter chart
scatter_chart = ScatterChart()
series = Series(values=values,  xvalues=dates, title="Gold Prices")
scatter_chart.series.append(series)
scatter_chart.title = 'Gold Prices Over The Last 10 Days - Scatter Chart'
scatter_chart.x_axis.title = 'Date'
scatter_chart.y_axis.title = 'Price'
sheet.add_chart(scatter_chart, 'F60')

# Saving the xlsx workbook
wb.save("GoldPricesCharts.xlsx")

print('Done')