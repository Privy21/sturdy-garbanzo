import requests
import bs4

res = requests.get("https://4d5716c7-e368-4ad0-9cfd-7c790eb28e1d-00-20gj71qmzk9b5.worf.replit.dev/index.html")

#print(res.raise_for_status())

parseSoup = bs4.BeautifulSoup(res.text, 'html.parser')

elements = parseSoup.select('p')

print(elements)

Privy =open("Privy.txt", "wb")

for char in res.iter_content(5):

  Privy.write(char)