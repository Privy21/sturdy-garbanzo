from flask import Flask, render_template, jsonify
import os
from twilio.rest import Client
from weather import get_weather
from space import get_number
from hp_character import get_char
import random
import json

app = Flask('app')

@app.route('/')
def home():
  return render_template("index.html")


@app.route('/privy/sms',  methods=['GET'])
def send_sms():

    account_sid = 'ACd674a92362cb115bc2f5f667ebd8e198'  # your sid
    auth_token = 'd22ae8105860a1bdfd7577c2fc0fffb4'  # your auth token
    client = Client(account_sid, auth_token)
    #Create a database with student information.
    student = {
        "Anesu": {
            "name": "Anesu",
            "phone_number": "+14168901527",
            "city": "Sudbury",
            "province": "Ontario"
        }
    }

    # Creating a customized message for each student with information provided by different APIs.
    for key, value in student.items():
        msg = f"Welcome {value['name']} to the wonders of technology,your phone number is {value['phone_number']} and you currently live in {value['city']},{value['province']} where the weather is {get_weather(value['city'])} degrees Celsius .{get_number()}. {get_char()}"

        message = client.messages.create(
            body=msg,  # this is the message that gets send
            from_='+19064225386',  #Virtual number from twilio
            to=value['phone_number'],  # canadian number
        )

        print(message.body)
        
        with open('messages.json', 'w') as json_file:
            json.dump(msg, json_file) 
        
    return jsonify({"message" : "Successfully sent"})


app.run(host='0.0.0.0', port=8080)
