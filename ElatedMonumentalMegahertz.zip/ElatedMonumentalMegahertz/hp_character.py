import urllib.request
import json
import random


def get_char():
    url = 'https://hp-api.onrender.com/api/characters'
    request = urllib.request.urlopen(url)
    result = json.loads(request.read())
    char = random.randint(1, 70)

    if result[char]["wizard"]:
        return f"{result[char]['name']} is a wizard and this role is played by actor {result[char]['actor']}."

    else:
        return f"{result[char]['name']} is not a wizard and it is played by actor {result[char]['actor']}."
