import urllib.request
import json

def get_weather(city):
    url = f'https://api.openweathermap.org/data/2.5/weather?q={city}&appid=7511f65f683b647f3d6d95a3afb5c03f'
    request = urllib.request.urlopen(url) 
    result = json.loads(request.read())
    temp_c = round(result["main"]["temp"] - 273.15,2)
    return temp_c