import urllib.request
import json
import pygal


# Storing the dresults in a list called data.

data = []

for value in range(7):
  url = f'https://cdn.jsdelivr.net/npm/@fawazahmed0/currency-api@2024-03-0{2+value}/v1/currencies/usd.json'
  request = urllib.request.urlopen(url)
  result = json.loads(request.read())
  data.append(result['usd']['cad'])

# Plotting our data using the pygal package

line_chart = pygal.Line()
line_chart.x_labels = [f"2024-03-0{2+i}" for i in range(7)]
#line_chart.y_labels = [1.34, 1.35, 1.36, 1.37]
line_chart.title = 'USD to CAD Exchange'
line_chart.add('USD to CAD', data)
line_chart.render_to_file('usd_cad_exchange.svg')
print('Done')
