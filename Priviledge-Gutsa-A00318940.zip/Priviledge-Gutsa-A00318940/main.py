# app.py
import nasdaqdatalink
from flask import Flask, render_template
import pygal
import pandas as pd

app = Flask(__name__)

# Configure Nasdaq Data Link API
nasdaqdatalink.ApiConfig.api_key = 'ZXYa7dtD6FAxMxLW3yK6'

# Creating a function that will fetch and process data from Nasdaq Data Link API.
def get_chart_data(code, days=15):
    data = nasdaqdatalink.get_table('QDL/BCHAIN', code=code)
    data = data.sort_values(by='date', ascending=True).tail(days)
    return [
        (row['date'].strftime('%Y-%m-%d'), row['value'])
        for _, row in data.iterrows()
    ]

# Creating a function that will plot charts from the processed data.
def create_line_chart(data, title):
    dates, values = zip(*data)
    chart = pygal.Line(
        x_label_rotation=45,
        show_legend=False,
        height=400,
        explicit_size=True,
        title=title,
        style=pygal.style.CleanStyle
    )
    chart.x_labels = dates
    chart.add('Value', values)
    return chart.render(is_unicode=True)

@app.route('/')
def dashboard():
    # Get TVTVR data and chart
    tvtvr_data = get_chart_data('TVTVR')
    tvtvr_chart = create_line_chart(
        tvtvr_data, 
        'Bitcoin Trade Volume vs Transaction Volume Ratio (TVTVR)'
    )

    # Get Network Deficit data and chart
    netdf_data = get_chart_data('NETDF')
    netdf_chart = create_line_chart(
        netdf_data,
        'Bitcoin Network Deficit (NETDF)'
    )

    return render_template(
        'dashboard.html',
        tvtvr_chart=tvtvr_chart,
        netdf_chart=netdf_chart
    )

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080)