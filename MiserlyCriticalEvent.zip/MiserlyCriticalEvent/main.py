import os
from twilio.rest import Client
from weather import get_weather
from space import get_number
from hp_character import get_char
import random

account_sid = 'ACd674a92362cb115bc2f5f667ebd8e198' # your sid 
auth_token = 'd22ae8105860a1bdfd7577c2fc0fffb4' # your auth token
client = Client(account_sid, auth_token)

#Create a database with student information.
student = {
    "Anesu":{
        "name":"Anesu",
        "phone_number":"+14168901527",
        "city":"Sudbury",
        "province":"Ontario"
    },
    "Trevor":{
        "name":"Trevor",
        "phone_number":"+17055622371",
        "city":"Barrie",
        "province":"Ontario"
    },
    "Blessing":{
        "name":"Blessing",
        "phone_number":"+17059196660",
        "city":"Toronto",
        "province":"Ontario"
    },
}
# Creatijng a customized message for each student with information provided by different APIs.
for key,value in student.items():
    msg=f"Welcome {value['name']} to the wonders of technology,your phone number is{value['phone_number']} and you currently live in {value['city']},{value['province']} where the weather is {get_weather(value['city'])} degrees Celsius .{get_number()}. {get_char()}"


    message = client.messages.create(
        body=msg, # this is the message that gets send
        from_='+19064225386', #Virtual number from twilio
        to=value['phone_number'], # canadian number
    )

    print(message.body)