import geopy.distance

def distance(coords_1_lat, coords_1_lon,coords_2_lat,coords_2_lon):
    coords_1 = (coords_1_lat, coords_1_lon) # coordinates of ISS
    coords_2 = () # coordinates of my place of residence where i stay (1393 Magnolia, Boulevard, Sudbury, ON)

    return (geopy.distance.distance(coords_1, coords_2).km)

# The source code for the distance calculation has been obtained on stakeoverflow accessible using the below link
# https://stackoverflow.com/questions/19412462/getting-distance-between-two-points-based-on-latitude-longitude