import urllib.request
import json

def weather_info(lat, lon):
    key = "7511f65f683b647f3d6d95a3afb5c03f"
    url =f"https://api.openweathermap.org/data/2.5/weather?lat={lat}&lon={lon}&appid={key}"

    response = urllib.request.urlopen(url)
    result = json.loads(response.read())

    # temp_C = round(result["main"]["temp"]-273.15,2)
    # desc = result["weather"][0]["description"]
    # print(str(temp_C) + "C", desc)
    return result


