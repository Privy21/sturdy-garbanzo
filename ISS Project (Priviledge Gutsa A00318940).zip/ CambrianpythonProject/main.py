# Locating the ISS (Latitude and Longitude) and including an image of it.

# Show the weather below the Space Station in degrees celcius.

# Show the country the ISS is above using reverse geolocation and in the event  that it is above the water
# tell the user.

# If the ISS is above a country will print some of the information about the country and show the national flag.

# Show the distance between my location and the ISS.

# Data for the page should refresh each time the html page is reloaded.


from get_issloc import iss_loc
from get_weather import weather_info
from get_address import address
from get_country import country
from get_distance import distance


# This is the location of the ISS
data = iss_loc()
lat, lon = data[0], data[1]

# This is the weather information below the ISS
weather = weather_info(lat,lon)
#print(weather)

#print(result)
temp_C = round(weather["main"]["temp"]-273.15,2)
desc = weather["weather"][0]["description"]
print(str(temp_C) + "C", desc)

# Obtaining the address of the country on which the ISS is directly above using reverse geolocation.
addr = address(lat,lon)
print("Country Code:", addr["countryCode"])

if addr["countryCode"]=="":
     print("The ISS is above water!")
else:
    print(f"The ISS is above a country with a country code {addr["countryCode"]}")


# The distance between my coordinates at my place of residence and that of the ISS is obtained as follows

dist = distance(lat,lon, 46.5278311,-80.9704788)
print(f"The distance between me and ISS is {dist} km")


# Showing the details and flag of the country over which the ISS is located.
location = addr["countryCode"]
flag = country(location)[0]["flags"]["png"]
print(flag)




