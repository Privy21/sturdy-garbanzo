import nasdaqdatalink
import  pandas as pd
import pygal

pd.set_option('display.max_rows', 500)
pd.set_option('display.max_columns', 10)
pd.set_option('display.width', 300)


nasdaqdatalink.ApiConfig.api_key = 'ZXYa7dtD6FAxMxLW3yK6'
TVTVR_data = nasdaqdatalink.get_table('QDL/BCHAIN',code='TVTVR')
NETDF_data = nasdaqdatalink.get_table('QDL/BCHAIN',code='NETDF')

#print(TVTVR_data)
#print(NETDF_data)

# Navigating the data frame
#print(TVTVR_data.iloc[0])
#print(TVTVR_data.iloc[0,0]) Code
#print(TVTVR_data.iloc[0,1]) Date 
#print(TVTVR_data.iloc[0,2]) Value
#print(NETDF_data.iloc[0,2]) Value


# Creating a list for Bitcoin Trade Volume vs Transaction Volume Ratio (TVTVR)
TVTVR_data = TVTVR_data.head(15)

TVTVR_list = []

for index, row in TVTVR_data.iterrows():
  # Converting the date stamp to time formant (%Y-%m-%d).
  date = row[1].strftime('%Y-%m-%d')
  # Appending the data to the list.
  TVTVR_list.append([date, row[2]])
  #print(TVTVR_list)
  # Separting the date and time from the list.
  dates,value = zip(*TVTVR_list)


# Plotting the Line Chart
tvtvr_chart = pygal.Line(x_label_rotation =45)
tvtvr_chart.title = 'Bitcoin Trade Volume vs Transaction Volume Ratio'
tvtvr_chart.x_labels = dates
tvtvr_chart.add('Values', value)
tvtvr_chart.render_to_file('Bitcoin_Trade_Volume_vs_Transaction_Volume_Ratio.svg')




# Creating a list for Bitcoin Network Deficit (NETDF)
NETDF_data = NETDF_data.head(15)

NETDF_list = []

for index, row in NETDF_data.iterrows():
  # Converting the date stamp to time formant (%Y-%m-%d).
  date = row[1].strftime('%Y-%m-%d')
  # Appending the data to the list.
  NETDF_list.append([date, row[2]])
  #print(TVTVR_list)
  # Separting the date and time from the list.
  dates,value = zip(*NETDF_list)


# Plotting the Line Chart
netdf_chart = pygal.Line(x_label_rotation =45)
netdf_chart.title = 'Bitcoin Network Deficit'
netdf_chart.x_labels = dates
netdf_chart.add('Values', value)
netdf_chart.render_to_file('Bitcoin_Network_Deficit.svg')

print('Line Chart Generated. You may download the file!')