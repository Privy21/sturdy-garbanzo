from fastapi import FastAPI, HTTPException
import requests
import uvicorn
from fastapi.responses import HTMLResponse
import logging

app = FastAPI()

# Set up logging
logging.basicConfig(level=logging.INFO)

def check_player(player_id):
    api_url = f"https://api.balldontlie.io/v1/players/{player_id}"
    api_key = "77723dec-29fd-4aef-8c54-39ef4e8a77a0"

    headers = {"Authorization": f"{api_key}"}

    player_data = []

    response = requests.get(api_url, headers = headers)

    if response.status_code == 200:
        player_data.append(response.json())
        
        player_first_name = player_data[0]["data"]["first_name"]
        player_last_name = player_data[0]["data"]["last_name"]
        player_position = player_data[0]["data"]["position"]
        player_country = player_data[0]["data"]["country"]
        logging.info(f"Player data retrieved: {player_data}")
        return player_first_name, player_position, player_last_name, player_country
    else:
        logging.error(f"Failed to retrieve player: {response.status_code}")
        raise HTTPException(status_code=response.status_code, detail="Player not found")




def check_game(game_id):
    api_url = f"https://api.balldontlie.io/v1/games/{game_id}"
    api_key = "77723dec-29fd-4aef-8c54-39ef4e8a77a0"

    headers = {"Authorization": f"{api_key}"}

    game_data = []

    response = requests.get(api_url, headers = headers)

    if response.status_code == 200:
        game_data.append(response.json())

        
        game_season = game_data[0]["data"]["season"]
        game_home_team_name = game_data[0]["data"]["home_team"]["name"]
        game_visitor_team_name = game_data[0]["data"]["visitor_team"]["name"]
        game_home_team_score = game_data[0]["data"]["home_team_score"]
        game_visitor_team_score = game_data[0]["data"]["visitor_team_score"]
        logging.info(f"Game data retrieved: {game_data}")
        return game_season, game_home_team_name, game_visitor_team_name, game_home_team_score, game_visitor_team_score
    else:
        logging.error(f"Failed to retrieve game: {response.status_code}")
        raise HTTPException(status_code=response.status_code, detail="Game not found")


# Calculate the average score between the home and visiting team.

def average_score(game_id):
    api_url = f"https://api.balldontlie.io/v1/games/{game_id}"
    api_key = "77723dec-29fd-4aef-8c54-39ef4e8a77a0"

    headers = {"Authorization": f"{api_key}"}

    game_data = []

    response = requests.get(api_url, headers = headers)

    if response.status_code == 200:
        game_data.append(response.json())


        game_home_team_score = game_data[0]["data"]["home_team_score"]
        game_visitor_team_score = game_data[0]["data"]["visitor_team_score"]

        logging.info(f"Game data retrieved: {game_data}")
        return (game_home_team_score + game_visitor_team_score)/2
    else:
        logging.error(f"Failed to retrieve game: {response.status_code}")
        raise HTTPException(status_code=response.status_code, detail="Game not found")


@app.get("/",response_class=HTMLResponse)
def dashboard():
    return """
    <html>
        <head>
        <title>Balldontlie Dashboard</title>
        <style>         
            body{
                background-color: lightgray
            }
        </style>
        </head>
        <body>
        <center>
            <h1>Balldontlie Dashboard</h1>
            <h2>View Player Details</h2>
            <form action="/player" method="get">
                <label for="player_id">Enter Player ID:</label>
                <input type="number" id="player_id" name="player_id" required>
                <input type="submit" value="Get Player Info">
            </form>
            <h2>View Game Details</h2>
            <form action="/game" method="get">
                <label for="game_id">Enter Game ID:</label>
                <input type="number" id="game_id" name="game_id" required>
                <input type="submit" value="Get Game Info">
            </form>
            <h2>View Average Score</h2>
            <form action="/average" method="get">
            <label for="game_id">Enter Game ID:</label>
            <input type="number" id="game_id" name="game_id" required>
            <input type="submit" value="Get Average Score">
            </form>
        </center>
        </body>
    </html>
    """

@app.get("/player")
def get_player_info(player_id: int):
    player_full_name, player_position, player_last_name, player_country = check_player(player_id)
    str_player = f"The player with id number {player_id} is {player_full_name} {player_last_name}. He plays the {player_position} position and is from {player_country}."
    return {"player_info": str_player}

@app.get("/game")
def get_game_info(game_id: int):
    game_season, game_home_team_name, game_visitor_team_name, game_home_team_score, game_visitor_team_score = check_game(game_id)
    str_game = f"During the {game_season} season, {game_home_team_name} played against {game_visitor_team_name} and the results were {game_home_team_score} - {game_visitor_team_score} respectively."
    return {"game_info": str_game}


@app.get("/average")
def get_average_score(game_id: int):
    game_season, game_home_team_name, game_visitor_team_name, game_home_team_score, game_visitor_team_score= check_game(game_id)
    str_game = f"The home team made {game_home_team_score} scores whilst the visiting team attained {game_visitor_team_score} scores, hence an average score of {(game_home_team_score + game_visitor_team_score)/2} between the two teams."
    return {"game_info": str_game}

if __name__ == "__main__":
    uvicorn.run(app, host='0.0.0.0', port=8080)